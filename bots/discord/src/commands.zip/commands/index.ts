// bots/discord/commands/index.ts
import type { Message } from 'discord.js';
import help from './help';
import inputPlayer from './inputPlayer';
import inputDiscordName from './inputDiscordName';
import inputTwitchName from './inputTwitchName';
import myStats from './myStats';
import stats from './stats';
import myWallet from './myWallet';
import search from './search';
import ladder from './ladder';
import myMatchHistory from './myMatchHistory';
import matchHistory from './matchHistory';
import bet from './bet';
import record from './record';
import remove from './remove';
import listAll from './listall';

export type CommandContext = {
  msg: Message;
  args: string[];
  isMod: boolean;
  helpers: {
    API_BASE: string;
    getJSON: (path: string) => Promise<any>;
    postJSON: (path: string, body: any) => Promise<any>;
    patchJSON: (path: string, body: any) => Promise<any>;
    delJSON: (path: string, body?: any) => Promise<any>;
  };
};
export type Command = (ctx: CommandContext) => Promise<void>;

export function buildCommandMap(): Map<string, Command> {
  return new Map<string, Command>([
    ['help', help],

    // Linking & profiles
    ['inputplayer', inputPlayer],
    ['inputdiscordname', inputDiscordName],
    ['inputtwitchname', inputTwitchName],

    // Info
    ['mystats', myStats],
    ['stats', stats],
    ['mywallet', myWallet],
    ['search', search],
    ['ladder', ladder],
    ['top10ladder', ladder],
    ['top10dsc', ladder],
    ['top10gpc', ladder],
    ['mymatchhistory', myMatchHistory],
    ['matchhistory', matchHistory],
    ['listall', listAll],

    // Betting & admin
    ['bet', bet],
    ['record', record],
    ['remove', remove],
  ]);
}
