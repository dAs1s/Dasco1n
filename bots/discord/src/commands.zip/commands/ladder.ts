// bots/discord/commands/ladder.ts
import type { Command } from './index';

const ladder: Command = async ({ msg, helpers }) => {
  const invoked = msg.content.slice((process.env.DISCORD_PREFIX ?? '!').length).split(/\s+/)[0].toLowerCase();
  const map: Record<string, string> = {
    top10dsc: '/api/leaderboards/dsc?limit=10',
    top10gpc: '/api/leaderboards/gpc?limit=10',
    top10ladder: '/api/leaderboards/elo?limit=10',
    ladder: '/api/leaderboards/elo?limit=1000',
  };
  const path = map[invoked] ?? map['ladder'];
  try {
    const data = await helpers.getJSON(path);
    const rows = (data.items ?? data.rows ?? data.users ?? data ?? []);
    if (!rows.length) return void msg.reply('No ladder data.');
    const lines = rows.map((r: any) => `${String(r.rank ?? r.position ?? r.idx ?? '?').toString().padStart(3,' ')}. ${r.username} — ${r.elo ?? r.value ?? r.balance ?? '?'}`);
    const MAX = 1900;
    let buf = '```\n', out: string[] = [];
    for (const ln of lines) {
      if ((buf + ln + '\n```').length > MAX) { out.push(buf + '```'); buf = '```\n'; }
      buf += ln + '\n';
    }
    if (buf.trim() != '```') out.push(buf + '```');
    for (let i=0;i<out.length;i++) {
      const header = `**ELO Ladder — ${rows.length} players** (page ${i+1}/${out.length})\n`;
      if (i===0) await msg.reply(header + out[i]); else await msg.channel.send(header + out[i]);
    }
  } catch (e:any) {
    await msg.reply('Ladder error.');
  }
};
export default ladder;
